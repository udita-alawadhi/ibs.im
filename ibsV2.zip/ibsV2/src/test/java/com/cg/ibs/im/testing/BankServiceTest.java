package com.cg.ibs.im.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.cg.ibs.bean.ApplicantBean;
import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicantDaoImpl;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.service.BankerSeviceImpl;
import com.cg.ibs.im.service.CustomerServiceImpl;

public class BankServiceTest {

	BankerSeviceImpl bankerService = new BankerSeviceImpl();
	CustomerServiceImpl customerService = new CustomerServiceImpl();

	@Test
	void updateStatusTest() throws IOException {
		try {
			assertEquals(true, bankerService.updateStatus(13680, ApplicantStatus.PENDING));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void generatePasswordTest() {
		assertNotNull(bankerService.generatePassword(12050));
	}

	@Test
	void generateUsernameTest() {
		try {
			assertNotNull(bankerService.generateUsername(15001));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void generateUserNameNuetralTest() {
		Assertions.assertThrows(Exception.class, () -> {
			bankerService.generateUsername(10080);
		});
	}

//	@Test
//	void isApplicantPresentTest() {
//		assertTrue(ApplicantDaoImpl.isApplicantPresent(12345));
//	}

	@Test
	void generateUciTest() {
		assertNotNull(BankerSeviceImpl.generateUci());
	}

	@Test
	void verifyLoginPositiveTest() {
		
		try {
			assertEquals(true, bankerService.verifyLogin("id1", "pass1"));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("Customer not present", throwable.getMessage());
		}
	}

	@Test
	void verifyLoginNegativeTest() {
		try {
			assertEquals(false, bankerService.verifyLogin("ad78924614", "p89249789124"));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("Customer not present", throwable.getMessage());
		}
	}

	@Test
	void createNewCustomerTest() {
		try {
			ApplicantBean bean = customerService.getApplicantDetails(15001);
		
			assertNotNull(bankerService.createNewCustomer(bean));
		}catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("Customer not present", throwable.getMessage());
		}
	}

	@Test
	void viewPendingApplicationsTest() throws SQLException {
		try {
			assertEquals(5, bankerService.viewPendingApplications().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void viewApprovedApplicationsTest() throws SQLException {
		try {
			assertEquals(2, bankerService.viewApprovedApplications().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}

	}

	@Test
	void viewDeniedApplicationsTest() throws SQLException {

		try {
			assertEquals(0, bankerService.viewDeniedApplications().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}

	}

	@Test
	void displayDetailsTest() {
		ApplicantDao applicantDao = new ApplicantDaoImpl();
		try {
			assertNotNull(applicantDao.getApplicantDetails(15001));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Disabled
	@Test
	void getFilesAvialableTest() {
		CustomerServiceImpl customerServiceImpl = new CustomerServiceImpl();
		try {
			customerServiceImpl.upload("C://Users//ysandeep//Desktop//abc1.txt");
			assertEquals(2, bankerService.getFilesAvialable().size());
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("FILE NOT FOUND", throwable.getMessage());
		}

	}

	@Disabled
	@Test
	void isApplicantPresentInPendingListTest() {
		try {
			assertTrue(bankerService.isApplicantPresentInPendingList(10001));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

	@Test
	void isApplicantPresentTest() {
		try {
			assertTrue(bankerService.isApplicantPresent(10001));
		} catch (IBSCustomException exception) {
			Throwable throwable = assertThrows(IBSCustomException.class, () -> {
				throw new IBSCustomException(exception.getMessage());
			});
			assertSame("DATA NOT FOUND", throwable.getMessage());
		}
	}

}
