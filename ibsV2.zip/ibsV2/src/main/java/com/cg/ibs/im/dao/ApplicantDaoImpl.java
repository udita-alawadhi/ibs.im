package com.cg.ibs.im.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.cg.ibs.bean.AccountHolder;
import com.cg.ibs.bean.AccountType;
import com.cg.ibs.bean.ApplicantBean;
import com.cg.ibs.bean.ApplicantBean.ApplicantStatus;
import com.cg.ibs.bean.ApplicantBean.Gender;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.util.OracleConnection;
import com.cg.ibs.im.util.QueryMap;

public class ApplicantDaoImpl implements ApplicantDao {

	private ApplicantBean newApplicant = new ApplicantBean();
	private static final Logger LOGGER = Logger.getLogger(ApplicantDaoImpl.class);

	@Override
	public boolean saveApplicant(ApplicantBean applicant) throws IBSCustomException {
		LOGGER.info("In saveApplicant(ApplicantBean) method ");
		boolean result = false;
//		System.out.println(applicant.toString());
		if (applicant != null) {
			LOGGER.debug("Applicant is not null");
			Connection connection = OracleConnection.callConnection();
			try (PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMap.INSERT_APPLICANT_DETAILS);) {
				LOGGER.debug("Calling insertApplicantDetails query. About to set values");

				preparedStatement.setLong(1, applicant.getApplicantId());

				preparedStatement.setString(2, applicant.getFirstName());
				preparedStatement.setString(3, applicant.getLastName());
				preparedStatement.setString(4, applicant.getFatherName());
				preparedStatement.setString(5, applicant.getMotherName());
				LocalDate dob = applicant.getDob();
				java.sql.Date date = java.sql.Date.valueOf(dob);
				LOGGER.debug("dob- localdate converted to sql date");

				preparedStatement.setDate(6, date);
				preparedStatement.setString(7, applicant.getGender().toString());
				preparedStatement.setString(8, applicant.getMobileNumber());
				preparedStatement.setString(9, applicant.getAlternateMobileNumber());
				preparedStatement.setString(10, applicant.getEmailId());
				preparedStatement.setString(11, applicant.getAadharNumber());
				preparedStatement.setString(12, applicant.getPanNumber());
				preparedStatement.setString(13, applicant.getAccountType().toString());
				preparedStatement.setString(14, applicant.getAccountHolder().toString());
				preparedStatement.setString(15, applicant.getApplicantStatus().toString());
				LocalDate applicationDate = applicant.getApplicationDate();
				java.sql.Date dateOfApplication = java.sql.Date.valueOf(applicationDate);
				LOGGER.debug("dateOfApplication - localdate converted to sql date");

				preparedStatement.setDate(16, dateOfApplication);

				preparedStatement.setLong(17, applicant.getLinkedApplication());

//				System.out.println("cjhelc!!!!");
				LOGGER.debug("calling preparedStatement.executeUpdate");

				preparedStatement.executeUpdate();
				LOGGER.info("Applicant details has been successfully ");

//				System.out.println("bhvchdsb s "+ check);
//				if (check > 0) {
//					result = true;
//				}
			} catch (SQLException exception) {
				LOGGER.error("saveApplicant is showing exception as " + exception.getMessage());
//				exception.printStackTrace();
				throw new IBSCustomException(IBSException.SQLErrorInput);
//				System.out.println(exception.getMessage());
			}
		}

		return result;
	}

	@Override
	public boolean updateStatusToApproved(ApplicantBean applicant) throws IBSCustomException {
		LOGGER.info("In updateStatusToApproved(applicant) method ");

		boolean result = false;
		Connection connection = OracleConnection.callConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMap.UPDATE_APPLICANT_STATUS);) {
			LOGGER.debug("Calling UPDATE_APPLICANT_STATUS from QueryMap ");

			preparedStatement.setLong(1, applicant.getApplicantId());

			int check = preparedStatement.executeUpdate();
			if (check == 1) {
				LOGGER.debug("Applicant status pass");
				result = true;
			}
		} catch (SQLException exception) {
			LOGGER.error("updateStatusToApproved is showing exception as " + exception.getMessage());

			throw new IBSCustomException(IBSException.SQLErrorInput);
		}
		return result;
	}

	@Override
	public boolean updateLinkedApplication(ApplicantBean applicant) throws IBSCustomException {
		LOGGER.info("In updateLinkedApplication(applicant) method ");

		boolean result = false;
		Connection connection = OracleConnection.callConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMap.UPDATE_LINKED_APPLICATION);) {
			LOGGER.debug("Calling UPDATE_LINKED_APPLICATION from Query Map");
			preparedStatement.setLong(1, applicant.getLinkedApplication());
			preparedStatement.setLong(2, applicant.getApplicantId());

			int check = preparedStatement.executeUpdate();
			if (check == 1) {
				result = true;
				LOGGER.info("Linked Application Updated");
			}
		} catch (SQLException exception) {
			LOGGER.error("updateLinkedApplication is showing exception as " + exception.getMessage());
			throw new IBSCustomException(IBSException.SQLErrorInput);
		}
		return result;
	}

	@Override
	public Set<Long> getAllApplicants() throws IBSCustomException {
		LOGGER.info("In getAllApplicants() method ");

		Set<Long> applicantSet = new HashSet<Long>();

		Connection connection = OracleConnection.callConnection();
		try (PreparedStatement statement = connection.prepareStatement(QueryMap.GET_ALL_APPLICATIONS);) {
			LOGGER.debug("Calling GET_ALL_APPLICATIONS from Query Map. About to retrieve");
			try (ResultSet resultSet = statement.executeQuery();) {
				{
					int index = 1;

					while (resultSet.next()) {
						applicantSet.add(resultSet.getLong(index));
						index++;
						LOGGER.info("All Applicants fetched");

					}
				}
			}
		} catch (SQLException exception) {
			LOGGER.error("getAllApplicants is showing exception as " + exception.getMessage());
			throw new IBSCustomException(IBSException.SQLError);
		}
		return applicantSet;
	}

	@Override
	public boolean isApplicantPresent(long applicantId) throws IBSCustomException {
		LOGGER.info("In isApplicantPresent(applicantId) method ");

		boolean result = false;

		Connection connection = OracleConnection.callConnection();
		try (PreparedStatement statement = connection.prepareStatement(QueryMap.GET_APPLICANT_DETAILS);) {
			LOGGER.debug("Calling GET_APPLICANT_DETAILS query. About to get values");

			statement.setLong(1, applicantId);
			int updateCheck = statement.executeUpdate();
			try (ResultSet resultSet = statement.executeQuery();) {
				if (updateCheck == 1) {
					result = true;
					LOGGER.info("Applicant is present");

				}
			}

		} catch (SQLException exception) {
			LOGGER.error("isApplicantPresent is showing exception as " + exception.getMessage());

			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantId) throws IBSCustomException {
		LOGGER.info("In getApplicantDetails(applicantId) method ");

		Connection connection = OracleConnection.callConnection();
		try (PreparedStatement statement = connection.prepareStatement(QueryMap.GET_APPLICANT_DETAILS);) {
			LOGGER.debug("Calling GET_APPLICANT_DETAILS query. About to get values");

			statement.setLong(1, applicantId);
			try (ResultSet resultSet = statement.executeQuery();) {
				if (resultSet.next()) {
					newApplicant.setApplicantId(applicantId);
					newApplicant.setFirstName(resultSet.getString(2));
					newApplicant.setLastName(resultSet.getString(3));
					newApplicant.setFatherName(resultSet.getString(4));
					newApplicant.setMotherName(resultSet.getString(5));
					java.sql.Date date = resultSet.getDate(6);
					LOGGER.debug("dob- localdate converted to sql date");

					LocalDate dob = date.toLocalDate();
					newApplicant.setDob(dob);

					String gender = resultSet.getString(7);
					if (gender.toUpperCase().equals("MALE")) {
						newApplicant.setGender(Gender.MALE);
					} else if (gender.toUpperCase().equals("FEMALE")) {
						newApplicant.setGender(Gender.FEMALE);
					} else if (gender.toUpperCase().equals("OTHERS")) {
						newApplicant.setGender(Gender.OTHERS);
					}
					newApplicant.setMobileNumber(resultSet.getString(8));
					newApplicant.setAlternateMobileNumber(resultSet.getString(9));
					newApplicant.setEmailId(resultSet.getString(10));
					newApplicant.setAadharNumber(resultSet.getString(11));
					newApplicant.setPanNumber(resultSet.getString(12));

					String accountType = resultSet.getString(13);
					if (accountType.toUpperCase().equals("JOINT")) {
						newApplicant.setAccountType(AccountType.JOINT);
					} else if (accountType.toUpperCase().equals("INDIVIDUAL")) {
						newApplicant.setAccountType(AccountType.INDIVIDUAL);
					}

					String accountHolder = resultSet.getString(14);
					if (accountHolder.toUpperCase().equals("PRIMARY")) {
						newApplicant.setAccountHolder(AccountHolder.PRIMARY);
					} else if (accountHolder.toUpperCase().equals("SECONDARY")) {
						newApplicant.setAccountHolder(AccountHolder.SECONDARY);
					}

					String applicantStatus = resultSet.getString(15);
					if (applicantStatus.toUpperCase().equals("PENDING")) {
						newApplicant.setApplicantStatus(ApplicantStatus.PENDING);
					} else if (applicantStatus.toUpperCase().equals("APPROVED")) {
						newApplicant.setApplicantStatus(ApplicantStatus.APPROVED);
					} else if (applicantStatus.toUpperCase().equals("DENIED")) {
						newApplicant.setApplicantStatus(ApplicantStatus.DENIED);
					}

					java.sql.Date applicationDate = resultSet.getDate(16);
					LocalDate dateOfApplication = applicationDate.toLocalDate();
					LOGGER.debug("dateOfApplication - localdate converted to sql date");

					newApplicant.setApplicationDate(dateOfApplication);

					newApplicant.setLinkedApplication(resultSet.getLong(17));
//					newApplicant.setExistingCustomer(resultSet.getBoolean(18));
				}
			}
		} catch (SQLException exception) {
			LOGGER.error("getApplicantDetails is showing exception as " + exception.getMessage());
			exception.printStackTrace();
			throw new IBSCustomException(IBSException.SQLError);
		}
		return newApplicant;
	}

	@Override
	public Set<Long> getApplicantsByStatus(ApplicantStatus applicantStatus) throws IBSCustomException {
		LOGGER.info("In getApplicantsByStatus(applicantStatus) method ");

		Set<Long> applicantSet = new HashSet<Long>();
		Connection connection = OracleConnection.callConnection();

		try (PreparedStatement statement = connection.prepareStatement(QueryMap.GET_ALL_APPLICATIONS_BY_STATUS);) {
			LOGGER.debug("Calling GET_ALL_APPLICATIONS_BY_STATUS query. About to get values");

			statement.setString(1, applicantStatus.toString().toUpperCase());
			try (ResultSet resultSet = statement.executeQuery();) {

				while (resultSet.next()) {
					long temp = resultSet.getLong("applicant_id");
					applicantSet.add(temp);
					LOGGER.info("Applicant is present");

				}
			}
		} catch (SQLException exception) {
			LOGGER.error("getApplicantsByStatus is showing exception as " + exception.getMessage());

//			exception.printStackTrace();
			throw new IBSCustomException(IBSException.SQLError);
		}

		return applicantSet;
	}

	@Override
	public boolean validateBankLogin(String userId, String password) throws IBSCustomException {
		LOGGER.info("In validateBankLogin(userId,password) method ");

		boolean status = false;
		Connection connection = OracleConnection.callConnection();
		if (checkIfBankerExists(userId)) {
			try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMap.BANKER_DETAILS);) {
				LOGGER.debug("Calling BANKER_DETAILS  query.  Validating");

				preparedStatement.setString(1, userId);
				try (ResultSet resultSet = preparedStatement.executeQuery();) {
					if (resultSet.next()) {
						String tempPassword = resultSet.getString("PASSWORD");
						if (password.equals(tempPassword)) {
							status = true;
							LOGGER.info("Successfully logged in");

						}
					}
				}
			} catch (SQLException exception) {
				LOGGER.error("validateBankLogin is showing exception as " + exception.getMessage());

				throw new IBSCustomException(IBSException.SQLError);
			}
		}

		return status;
	}

	public boolean checkIfBankerExists(String userId) throws IBSCustomException {
		LOGGER.info("In checkIfBankerExists(userId) method ");

		boolean status = false;
		Connection connection = OracleConnection.callConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMap.BANKER_DETAILS);) {
			LOGGER.debug("Calling BANKER_DETAILS  query.  Validating");

			
			preparedStatement.setString(1, userId);

			int index = preparedStatement.executeUpdate();
			if (index == 1) {
				status = true;
				LOGGER.info("Banker present");

			}
		} catch (SQLException exception) {
			LOGGER.error("checkIfBankerExists is showing exception as " + exception.getMessage());

			throw new IBSCustomException(IBSException.SQLError);
		}
		return status;
	}

}
