package com.cg.ibs.im.ui;

public enum UserMenu {
	BANKER, CUSTOMER, SERVICE_PROVIDER, QUIT
}


