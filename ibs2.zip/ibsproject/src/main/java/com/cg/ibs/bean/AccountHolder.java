package com.cg.ibs.bean;

public enum AccountHolder {
	PRIMARY, SECONDARY
}
